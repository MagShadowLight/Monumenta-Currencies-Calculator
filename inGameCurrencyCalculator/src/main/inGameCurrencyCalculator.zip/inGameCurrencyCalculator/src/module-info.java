/**
 * 
 */
/**
 * @author Willi
 *
 */
module inGameCurrencyCalculator {
}